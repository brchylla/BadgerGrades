CREATE DATABASE  IF NOT EXISTS `video_game_store_chain` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `video_game_store_chain`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: video_game_store_chain
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `store_location`
--

DROP TABLE IF EXISTS `store_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store_location` (
  `StoreLocationID` int(11) NOT NULL AUTO_INCREMENT,
  `StoreAddress` varchar(45) NOT NULL,
  `PostalCode` int(11) NOT NULL,
  PRIMARY KEY (`StoreLocationID`),
  UNIQUE KEY `StoreLocationID_UNIQUE` (`StoreLocationID`),
  KEY `PostalCode_idx` (`PostalCode`),
  CONSTRAINT `PostalCode` FOREIGN KEY (`PostalCode`) REFERENCES `city` (`PostalCode`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_location`
--

LOCK TABLES `store_location` WRITE;
/*!40000 ALTER TABLE `store_location` DISABLE KEYS */;
INSERT INTO `store_location` VALUES (1,'4876 Verona Ave',53593),(2,'3862 McKee Rd',53719),(3,'283 Junction Rd',53717),(4,'7028 W Towne Way',53717),(5,'667 State St',53703),(6,'121 E Towne Mall',53704),(7,'4305 Lien Rd',53704),(8,'269 West Broadway',53713),(9,'9248 Bryn Mawr Ave',60018),(10,'6007 E Ontario St',60611),(11,'872 E Harrison St',60605),(12,'600 E Grand Ave',60611),(13,'294 W 100th St',60643),(14,'583 E 83rd St',60617),(15,'3687 Jackson Ave',60540),(16,'5 Woodfield Mall',60173),(17,'100 Oakbrook Center',60523),(18,'56 S Washington Ave',55401),(19,'872 E Hennepin Ave',55414),(20,'60 East Broadway',55425),(21,'56 S Washington Ave',55401),(22,'61 7th St W',55102);
/*!40000 ALTER TABLE `store_location` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-27  1:01:03
