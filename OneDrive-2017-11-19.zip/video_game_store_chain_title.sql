CREATE DATABASE  IF NOT EXISTS `video_game_store_chain` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `video_game_store_chain`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: video_game_store_chain
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `title`
--

DROP TABLE IF EXISTS `title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `title` (
  `TitleID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(45) NOT NULL,
  PRIMARY KEY (`TitleID`),
  UNIQUE KEY `TitleID_UNIQUE` (`TitleID`),
  UNIQUE KEY `Title_UNIQUE` (`Title`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `title`
--

LOCK TABLES `title` WRITE;
/*!40000 ALTER TABLE `title` DISABLE KEYS */;
INSERT INTO `title` VALUES (36,'Battlefield 2'),(15,'Brain Age'),(8,'Call of Duty'),(46,'Car Charger'),(55,'Console'),(42,'Controller'),(35,'Counter-Strike'),(37,'Donkey Kong Country'),(26,'Doom 3'),(41,'Dr. Mario'),(44,'Ethernet Cable'),(28,'God of War'),(21,'Goldeneye 007'),(17,'Gran Turismo'),(27,'Grand Theft Auto: San Andreas'),(16,'Grand Theft Auto: Vice City'),(45,'Guitar Controller'),(4,'Guitar Hero 2'),(25,'Half-Life'),(2,'Half-Life 2'),(1,'Halo 2'),(9,'Halo: Combat Evolved'),(56,'Handheld System'),(29,'Kingdom Hearts'),(54,'Kingdom Hearts: Chain of Memories'),(13,'Lego Star Wars'),(30,'Madden NFL 2005'),(31,'Medal of Honor: Frontline'),(48,'Memory Card'),(22,'Metal Gear Solid'),(52,'Metal Gear Solid 2: Sons of Liberty'),(53,'Metal Gear Solid 3: Snake Eater'),(51,'Metal Gear Solid: Twin Snakes'),(11,'Metroid Prime'),(7,'Metroid Prime 2: Echoes'),(47,'Mouse & Keyboard'),(43,'Multi-Tap'),(3,'Nintendogs'),(20,'Perfect Dark'),(38,'Pokemon: Gold Version'),(5,'Pokemon: Ruby Version'),(6,'Pokemon: Sapphire Version'),(39,'Pokemon: Silver Version'),(18,'Resident Evil'),(34,'Roller Coaster Tycoon'),(49,'Sonic Adventure 2'),(50,'Soulcalibur'),(32,'Spider-Man 2'),(33,'Starcraft'),(19,'Super Mario 64'),(40,'Super Mario Land'),(24,'Super Smash Bros.'),(10,'Super Smash Bros. Melee'),(12,'The Legend of Zelda: Ocarina of Time'),(14,'The Sims 2'),(23,'Tomb Raider');
/*!40000 ALTER TABLE `title` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-27  1:01:03
