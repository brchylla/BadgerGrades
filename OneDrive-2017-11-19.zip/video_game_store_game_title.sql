CREATE DATABASE  IF NOT EXISTS `video_game_store` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `video_game_store`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: video_game_store
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `game_title`
--

DROP TABLE IF EXISTS `game_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_title` (
  `GameTitleID` int(11) NOT NULL AUTO_INCREMENT,
  `GameTitle` varchar(45) NOT NULL,
  `CurrentGenPrice` decimal(65,2) NOT NULL,
  PRIMARY KEY (`GameTitleID`),
  UNIQUE KEY `GameTitle` (`GameTitle`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_title`
--

LOCK TABLES `game_title` WRITE;
/*!40000 ALTER TABLE `game_title` DISABLE KEYS */;
INSERT INTO `game_title` VALUES (1,'Killzone: Shadow Fall',50.00),(2,'Titanfall',50.00),(3,'Battlefield 4',50.00),(4,'Call of Duty: Ghosts',50.00),(5,'Rayman: Legends',40.00),(6,'Super Mario 3D World',50.00),(7,'The Last of Us',50.00),(8,'Gears of War: Judgement',50.00),(9,'Uncharted: Golden Abyss',30.00),(10,'Assassins Creed',10.00),(11,'Fire Emblem: Awakening',50.00),(12,'Mario Kart 7',40.00),(13,'Super Mario Galaxy',40.00),(14,'Super Smash Bros. Brawl',50.00),(15,'Medal of Honor: Heroes 2',30.00),(16,'Metal Gear Solid: Peace Walker',40.00),(17,'God of War: Chains of Olympus',30.00),(18,'Grand Theft Auto: Chinatown Wars',50.00),(19,'New Super Mario Bros.',50.00),(20,'Scribblenauts',40.00),(21,'Resistance 2',5.00),(22,'Resistance: Fall of Man',3.00),(24,'Killzone 2',8.00);
/*!40000 ALTER TABLE `game_title` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-27  1:01:04
